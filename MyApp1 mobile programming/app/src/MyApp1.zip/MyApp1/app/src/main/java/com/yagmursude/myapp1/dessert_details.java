package com.yagmursude.myapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dessert_details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity);
    }
}